#!/bin/bash

IPADDRESS=$(/sbin/ifconfig | grep 'inet' |  awk '{print $2}' | grep -v '127.0.0.1')
zmnetwork=$(su - zimbra -c "postconf mynetworks" | awk '{print $4}')

if [ "$IPADDRESS/32" == "$zmnetwork" ]; then
    echo "IPADDRESS and zmnetwork are the same: $IPADDRESS"
else
subject="IP Address and zmnetwork mismatch"
    body="IPADDRESS: $IPADDRESS\nzmnetwork: $zmnetwork\nhostname: $(hostname)"
    printf "Subject: $subject\n\n$body" | sendmail -v pavan.kv@actcorp.in
    su - zimbra -c "zmprov ms $(hostname) zimbraMtaMyNetworks '127.0.0.0/8  $IPADDRESS/32 123.176.37.175/32 172.23.21.121/32 172.23.21.129/32 172.23.21.149/32'"
  su - zimbra -c " postfix reload"
fi





