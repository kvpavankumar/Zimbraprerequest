#!/bin/bash
set -x
my_array=( $(/opt/zimbra/bin/zmcontrol status| sed 's/webapp//g' ) )

for (( c=2; c<=26; c=c+2 )); do    j=$((c+1));    psql -U postgres -d  reports -h 10.100.112.139  -c  "INSERT INTO  mailservices (name ,service,status,date) VALUES  ('$(hostname)',' ${my_array[c]}','${my_array[j]}',current_timestamp)"; done

ALERT=80

var1=($(df -HP | grep -vE "^Filesystem|tmpfs|cdrom|loop*"| awk '{print $1}' ))
var2=($(df -HP | grep -vE "^Filesystem|tmpfs|cdrom|loop*"| awk '{print $2}' ))
var3=($(df -HP | grep -vE "^Filesystem|tmpfs|cdrom|loop*"| awk '{print $3}' ))
var4=($(df -HP | grep -vE "^Filesystem|tmpfs|cdrom|loop*"| awk '{print $4}' ))
var5=($(df -HP | grep -vE "^Filesystem|tmpfs|cdrom|loop*"| awk '{print $5}' |  sed 's/%//' ))
var6=($(df -HP | grep -vE "^Filesystem|tmpfs|cdrom|loop*"| awk '{print $6}' ))

for i in ${!var1[@]};do
usep=$(echo ${var5[i]} | awk '{ print $1}' | cut -d'%' -f1)

 if [ $usep -ge $ALERT ] ; then
   psql -U postgres -d  reports -h 10.100.112.139  -c  " INSERT INTO  Maildiskspace (Server ,Drive,Size,Used,Avail,use,Quota,date) VALUES  ('$(hostname)','${var6[i]}','${var2[i]}','${var3[i]}','${var4[i]}','${var5[i]}','Exceed',current_timestamp)";
       else
            psql -U postgres -d  reports -h 10.100.112.139  -c  " INSERT INTO  Maildiskspace (Server ,Drive,Size,Used,Avail,use,Quota,date) VALUES  ('$(hostname)','${var6[i]}','${var2[i]}','${var3[i]}','${var4[i]}','${var5[i]}','Not_Exceed',current_timestamp)";

                 fi

                      done

my_array=($(sudo ~/libexec/zmqstat))

var=( hold  corrupt deferred active incoming  )
 for (( c=0; c<=4; c++ )); do
 k=$(echo ${my_array[c]} |  grep -o '[0-9]*')
psql -U postgres -d  reports -h 10.100.112.139  -c  "INSERT INTO  Mailqueue(Server ,queuename,QueueNo,date) VALUES  ('$(hostname)','${var[c]}','$k',current_timestamp)";
done

